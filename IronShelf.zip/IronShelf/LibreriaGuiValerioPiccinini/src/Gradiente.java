import java.awt.*;
import javax.swing.*;

public class Gradiente extends JPanel {
    Color Color1;
    Color Color2;
    public Gradiente(Color c1, Color c2) {
        Color1 = c1;
        Color2 = c2;
    }
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;

        int width = getWidth();
        int height = getHeight();

        // Crea un gradiente lineare da sinistra a destra
        GradientPaint gradient = new GradientPaint(0, 0, Color1, width, height,Color2);

        g2d.setPaint(gradient);
        g2d.fillRect(0, 0, width, height);
    }
}