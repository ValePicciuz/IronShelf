import javax.swing.*;
import java.awt.*;

public class MainFrame {
    JFrame frame;

    public MainFrame(FileManager file) {
        frame = new JFrame("Archivio Libri");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 500);
        frame.setLocationRelativeTo(null);

        ImageIcon Icon= new ImageIcon("./Database/IronShelf.png");
        frame.setIconImage(Icon.getImage());

        // Creazione del pannello principale con BoxLayout
        Gradiente mainPanel = new Gradiente(new Color(83, 244, 246), new Color(250, 201, 26));
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));

        // Area di testo per visualizzare i libri
        JTextArea textArea = new JTextArea();
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);
        mainPanel.add(scrollPane);
        textArea.append(file.readFile());
        textArea.setBackground(Color.BLACK);
        textArea.setForeground(Color.WHITE);

        // Pannello per i bottoni
        Gradiente buttonPanel = new Gradiente(new Color(83, 244, 246), new Color(250, 201, 26));
        buttonPanel.setMaximumSize(new Dimension(2000, 30));
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER));

        JButton ModificaButton = new JButton("Modifica");
        ModificaButton.setOpaque(false);
        ModificaButton.setContentAreaFilled(false);
        ModificaButton.setMaximumSize(new Dimension(167, 30));
        ModificaButton.setForeground(new Color(147, 48, 248));
        ModificaButton.addActionListener(e -> {
            Main.ModificaDialog(file,frame);
        });


        // Bottone per inserire un libro
        JButton inserisciButton = new JButton("Inserisci Libro");
        inserisciButton.setOpaque(false);
        inserisciButton.setContentAreaFilled(false);
        inserisciButton.setMaximumSize(new Dimension(167, 30));
        inserisciButton.setForeground(new Color(34, 166, 4));
        inserisciButton.addActionListener(e -> {
            Main.MostraDialogoDiInserimento(file,frame);
        });
        // Aggiunta del bottone al suo pannello
        buttonPanel.add(inserisciButton);
        buttonPanel.add(ModificaButton);

        String[] BottoniFiltro= {"Filtri di ricerca", "Ricerca per titolo", "Ricerca per autore", "Ricerca per casa editrice", "Ricerca per anno", "Ricerca per genere", "Ricerca perido"};
        JComboBox<String> ButtonDropDown = new JComboBox<>(BottoniFiltro);
        ButtonDropDown.setMaximumSize(new Dimension(167, 30));
        ButtonDropDown.addActionListener(e -> {
            if(ButtonDropDown.getSelectedIndex()==1){
                Main.CercaLibro(file,frame);
            }
            else if( ButtonDropDown.getSelectedIndex()==2){
                Main.CercaAutore(file,frame);
            }
            else if( ButtonDropDown.getSelectedIndex()==3){
                Main.CercaEditore(file,frame);
            }
            else if( ButtonDropDown.getSelectedIndex()==4){
                Main.CercaAnno(file,frame);
            }
            else if( ButtonDropDown.getSelectedIndex()==5){
                Main.CercaGenere(file,frame);
            }
            else if (ButtonDropDown.getSelectedIndex()==6){
                Main.CercaPeriodo(file,frame);
            }
        });
        ButtonDropDown.setForeground(new Color(147, 60, 218));
        buttonPanel.add(ButtonDropDown);


        // Bottone per eliminare un libro
        JButton eliminaButton = new JButton("Elimina Libro");
        eliminaButton.setOpaque(false);
        eliminaButton.setContentAreaFilled(false);
        eliminaButton.setMaximumSize(new Dimension(167, 30));
        eliminaButton.setForeground(new Color(253, 30, 8));
        eliminaButton.addActionListener(e -> {
            Main.EliminaLibro(file,frame);
        });
        eliminaButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        // Aggiunta del bottone al suo pannello
        buttonPanel.add(eliminaButton);
        // Aggiunta del panel dei bottoni al pannello principale
        mainPanel.add(buttonPanel);

        // Aggiunta del pannello principale al frame
        frame.add(mainPanel);

        // Visualizzazione del frame
        frame.setVisible(true);
    }

}