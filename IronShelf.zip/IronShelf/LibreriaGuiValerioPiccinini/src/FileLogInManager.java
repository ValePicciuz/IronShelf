import javax.swing.*;
import java.io.*;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class FileLogInManager {
    File logfile;
    String AddPassword="password";
    public FileLogInManager(String logfilename){
        logfile=new File(logfilename);
        try{
            logfile.createNewFile();
        }
        catch(IOException e)
        {
            System.out.println("Error creating file");
        }
    }

    public Boolean LogInRead(String Utente,String Password) {
        Utente="Utente: "+Utente+" ";
        Password="Password: "+Password;
        String UserPasswd= Utente+Password;
        try(Scanner sc=new Scanner(new File(logfile.getAbsolutePath())))
        {
            while(sc.hasNextLine())
            {
                String lineUtente=sc.nextLine();
                if (lineUtente.equals(UserPasswd)) {
                    return true;
                }
            }
        }
        catch(FileNotFoundException e)
        {
            e.printStackTrace();
        }
        return false;
    }

    public Boolean FileIsEmpty() {
        try(Scanner scanner= new Scanner(new File(logfile.getAbsolutePath())))
        {
            try {
                String line = scanner.nextLine();
            }
            catch (NoSuchElementException e)
            {
                System.out.println("Error writing to file");
                //e.printStackTrace();
                return true;
            }
            return false;
        }
        catch (FileNotFoundException e)
        {
            System.out.println("Error writing to file");
            //e.printStackTrace();
            return false;
        }

    }

    public Boolean NewUser (String Utente,String Password, String AddPwd, JFrame frame) {
        Utente="Utente: "+Utente+" ";
        Password="Password: "+Password+"\n";
        String UserPasswd= Utente+Password;
        Boolean aggiungi=true;
            if (!AddPwd.equals(AddPassword))
            {
                JOptionPane.showMessageDialog(frame,"NON SEI AUTORIZZATO A CREARE NUOVI UTENTI!");
                System.exit(2);
            }
        try(Scanner sc=new Scanner(new File(logfile.getAbsolutePath())))
        {
            while(sc.hasNextLine())
            {
                String lineUtente=sc.nextLine()+"\n";
                if (lineUtente.equals(UserPasswd)) {
                    aggiungi=false;
                }
            }
        }
        catch(FileNotFoundException e)
        {
            System.out.println("Error writing to file");
            e.printStackTrace();
        }
        if(aggiungi)
        {
            return AddUser(UserPasswd);
        }
        else
        {
            return false;
        }
    }

    public Boolean AddUser(String UserPasswd) {
        try(FileWriter writer = new FileWriter(logfile.getAbsolutePath(),true))
        {
            writer.append(UserPasswd);
            return true;
        }
        catch (IOException e)
        {
            System.out.println("Error writing to file");
            e.printStackTrace();
        }
        return true;
    }

}