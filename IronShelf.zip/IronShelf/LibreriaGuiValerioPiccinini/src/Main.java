import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.awt.event.*;

public class Main {
    public static LocalDate AnnoMinoreInserito= LocalDate.now();
    public static LocalDate AnnoMaggioreInserito= LocalDate.now();
    public static LocalDate year;

    public static void main(String[] args) {
        String FileLogName= "../Database/DatabaseLogIn.txt";
        FileLogInManager logFile=new FileLogInManager(FileLogName);
        if(logFile.FileIsEmpty())
        {
            new SignUp(logFile);
        }
        else
        {
            new Start(logFile);
        }
    }

    public static void MostraDialogoDiInserimento(FileManager f, Frame Mfr) {
        Mfr.dispose();
        JFrame addBookFrame = new JFrame("Add Book");
        addBookFrame.setSize(500, 400);
        addBookFrame.setLocationRelativeTo(null);

        ImageIcon Icon= new ImageIcon("../Database/IronShelf.png");
        addBookFrame.setIconImage(Icon.getImage());

        JPanel addBookPanel = new JPanel();
        addBookPanel.setLayout(new BoxLayout(addBookPanel, BoxLayout.Y_AXIS));
        addBookPanel.setBackground(Color.BLACK);

        Insets labelInsets = new Insets(5, 10, 5, 10);
        Insets fieldInsets = new Insets(5, 10, 5, 10);

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(Color.BLACK);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.weightx = 1;

        JLabel titleLabel = new JLabel("Titolo:");
        titleLabel.setForeground(Color.white);
        JTextField titleField = new JTextField();
        titleField.setPreferredSize(new Dimension(200, 30));

        titleField.setText("Inserisci il titolo...");
        titleField.setForeground(Color.GRAY);
        titleField.addFocusListener(new FocusListener() {
            public void focusGained(FocusEvent e) {
                if (titleField.getText().contains("Inserisci")) {
                    titleField.setText("");
                    titleField.setForeground(Color.BLACK);
                }
            }

            public void focusLost(FocusEvent e) {
                if (titleField.getText().isEmpty()) {
                    titleField.setText("Inserisci titolo...");
                    titleField.setForeground(Color.GRAY);
                }
            }
        });

        JLabel authorLabel = new JLabel("Autore:");
        authorLabel.setForeground(Color.white);
        JTextField authorField = new JTextField();
        authorField.setPreferredSize(new Dimension(200, 30));

        authorField.setText("Inserisci il titolo...");
        authorField.setForeground(Color.GRAY);
        authorField.addFocusListener(new FocusListener() {
            public void focusGained(FocusEvent e) {
                if (authorField.getText().contains("Inserisci")) {
                    authorField.setText("");
                    authorField.setForeground(Color.BLACK);
                }
            }

            public void focusLost(FocusEvent e) {
                if (authorField.getText().isEmpty()) {
                    authorField.setText("Inserisci autore...");
                    authorField.setForeground(Color.GRAY);
                }
            }
        });

        JLabel publisherLabel = new JLabel("Casa Editrice:");
        publisherLabel.setForeground(Color.white);
        JTextField publisherField = new JTextField("Inserisci casa editrice...");
        publisherField.setPreferredSize(new Dimension(200, 30));

        publisherField.setForeground(Color.GRAY);
        publisherField.addFocusListener(new FocusListener() {
            public void focusGained(FocusEvent e) {
                if (publisherField.getText().contains("Inserisci")) {
                    publisherField.setText("");
                    publisherField.setForeground(Color.BLACK);
                }
            }

            public void focusLost(FocusEvent e) {
                if (publisherField.getText().isEmpty()) {
                    publisherField.setText("Inserisci casa editrice...");
                    publisherField.setForeground(Color.GRAY);
                }
            }
        });

        JLabel yearLabel = new JLabel("Data di pubblicazione:");
        yearLabel.setForeground(Color.white);
        JButton yearField = new JButton("Inserisci data di publicazione");
        yearField.setPreferredSize(new Dimension(200, 30));


        /*yearField.addFocusListener(new FocusListener() {
            public void focusGained(FocusEvent e) {
                if (yearField.getText().contains("Inserisci")) {
                    yearField.setText("");
                    yearField.setForeground(Color.BLACK);
                }
            }
            public void focusLost(FocusEvent e) {
                if (yearField.getText().isEmpty()) {
                    yearField.setText("Inserisci data di publicazione(yyyy-MM-dd)...");
                    yearField.setForeground(Color.GRAY);
                }
            }
        });*/

        JLabel genereLabel = new JLabel("Genere:");
        genereLabel.setForeground(Color.white);
        String[] genres = {"Horror", "Romance", "Fantasy", "Si-Fi"};
        JComboBox<String> genereDropdown = new JComboBox<>(genres);
        genereDropdown.setMaximumSize(new Dimension(200, 30));

        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(titleLabel, gbc);
        gbc.gridx = 1;
        formPanel.add(titleField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        formPanel.add(authorLabel, gbc);
        gbc.gridx = 1;
        formPanel.add(authorField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        formPanel.add(publisherLabel, gbc);
        gbc.gridx = 1;
        formPanel.add(publisherField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        formPanel.add(yearLabel, gbc);
        gbc.gridx = 1;
        formPanel.add(yearField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        formPanel.add(genereLabel, gbc);
        gbc.gridx = 1;
        formPanel.add(genereDropdown, gbc);

        yearField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new Calendario(); // Apri il calendario
            }
        });

        JButton saveButton = new JButton("Save");
        saveButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                year = Calendario.selectedDate;
                yearField.setText(year.toString());

                String title = titleField.getText();
                String author = authorField.getText();
                String publisher = publisherField.getText();
                String anno = String.valueOf(year);
                String genere = (String) genereDropdown.getSelectedItem();
                try {
                    if (year.isAfter(LocalDate.now()))
                    {
                        JOptionPane.showMessageDialog(addBookFrame, "Inserisci un anno valido");
                    }
                    else if(title.equals("Inserisci titolo...") || author.equals("Inserisci autore...") || publisher.equals("Inserisci casa editrice...") || anno.equals("Inserisci data(yyyy-MM-dd)..."))
                    {
                        JOptionPane.showMessageDialog(addBookFrame, "Ci sono dei campi vuoti!");
                    }
                    else
                    {
                        f.InserisciLibro(title,author,publisher,year,genere);
                        // TODO: Implement saving the book to the collection
                        //System.out.println("Libro aggiunto: " + title + ", " + author + ", " + publisher + ", " + year + ", " + genre);
                        JOptionPane.showMessageDialog(addBookFrame, "Libro aggiunto con successo!!");
                        new MainFrame(f);
                        addBookFrame.dispose();
                    }
                } catch (DateTimeParseException datEx) {
                    datEx.printStackTrace();
                    JOptionPane.showMessageDialog(addBookFrame, "Inserisci un anno valido");
                    yearField.setText("");
                }
            }
        });

        addBookFrame.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent e) {
                new MainFrame(f);
                addBookFrame.dispose();
            }
        });
        saveButton.setAlignmentX(Component.CENTER_ALIGNMENT);

        addBookPanel.add(formPanel);
        addBookPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        addBookPanel.add(saveButton);

        addBookFrame.add(addBookPanel);
        addBookFrame.setVisible(true);
    }

    public static void EliminaLibro(FileManager f, Frame Mfr) {
        Mfr.dispose();
        JFrame removeBookFrame = new JFrame("Erase Book");
        removeBookFrame.setSize(300, 200);
        removeBookFrame.setLocationRelativeTo(null);

        ImageIcon Icon= new ImageIcon("../Database/IronShelf.png");
        removeBookFrame.setIconImage(Icon.getImage());

        Gradiente panel = new Gradiente(new Color(237, 7, 7), Color.BLACK);
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        removeBookFrame.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent e) {
                new MainFrame(f);
                removeBookFrame.dispose();
            }
        });

        JLabel titleLabel = new JLabel("Titolo:");
        titleLabel.setForeground(Color.white);
        JTextField titleField = new JTextField();
        titleField.setMaximumSize(new Dimension(200, 20));
        titleField.setAlignmentX(Component.CENTER_ALIGNMENT);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        JButton saveButton = new JButton("Elimina");
        saveButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        saveButton.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e) {
                String titolo=titleField.getText();
                System.out.println("il titolo preso dalla text area è: "+titolo);
                f.EliminaDaTitolo(titolo);
                JOptionPane.showMessageDialog(removeBookFrame, "Libro rimosso con successo!");
                new MainFrame(f);
                removeBookFrame.dispose();
            }
        });
            panel.add(titleLabel);
            panel.add(Box.createRigidArea(new Dimension(0,30)));
            panel.add(titleField);
            panel.add(Box.createRigidArea(new Dimension(0,20)));
             // Placeholder for layout alignment
            panel.add(saveButton);
            removeBookFrame.setVisible(true);
            removeBookFrame.add(panel);

    }

    public static void CercaAutore(FileManager f, Frame Mfr){
        Mfr.dispose();
        String autore = JOptionPane.showInputDialog("Autore da cercare");
        String LibroGiusto=f.StampaSoloX(autore,1);

        JFrame AuthorFrame = new JFrame("Filtro per autore: ");
        AuthorFrame.setSize(600,400);
        AuthorFrame.setLocationRelativeTo(null);
        JTextArea libriArea = new JTextArea();

        ImageIcon Icon= new ImageIcon("../Database/IronShelf.png");
        AuthorFrame.setIconImage(Icon.getImage());

        JPanel AuthorPanel = new JPanel();
        AuthorPanel.setLayout(new BoxLayout(AuthorPanel, BoxLayout.Y_AXIS));
        JButton OkButton = new JButton("Ok");

        OkButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        OkButton.addActionListener(e -> {
            JOptionPane.showMessageDialog(AuthorFrame, "Filtro rimosso");
            AuthorFrame.dispose();
            new MainFrame(f);
        });
        if (!LibroGiusto.equals("")) {
            AuthorFrame.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        new MainFrame(f);
                        AuthorFrame.dispose();
                    }
                });
            libriArea.append(LibroGiusto);
            AuthorPanel.add(libriArea);
            AuthorPanel.add(OkButton);
            AuthorFrame.add(AuthorPanel);
            AuthorFrame.setVisible(true);
        }
        else
        {
            JOptionPane.showMessageDialog(AuthorFrame, "Nessun libro è di questo autore!");
            new MainFrame(f);
        }
    }

    public static void CercaEditore(FileManager f, Frame Mfr) {
        Mfr.dispose();
        String autore = JOptionPane.showInputDialog("Casa editrice da cercare");
        String LibroGiusto=f.StampaSoloX(autore,2);

        JFrame EditorFrame = new JFrame("Filtro per casa editrice: ");
        EditorFrame.setSize(600,400);
        EditorFrame.setLocationRelativeTo(null);
        JTextArea libriArea = new JTextArea();

        ImageIcon Icon= new ImageIcon("../Database/IronShelf.png");
        EditorFrame.setIconImage(Icon.getImage());

        JPanel AuthorPanel = new JPanel();
        AuthorPanel.setLayout(new BoxLayout(AuthorPanel, BoxLayout.Y_AXIS));
        JButton OkButton = new JButton("Ok");

        OkButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        OkButton.addActionListener(e -> {
            JOptionPane.showMessageDialog(EditorFrame, "Filtro rimosso");
            EditorFrame.dispose();
            new MainFrame(f);
        });
        if (!LibroGiusto.equals("")) {
            EditorFrame.addWindowListener(new java.awt.event.WindowAdapter() {
                @Override
                public void windowClosing(java.awt.event.WindowEvent e) {
                    new MainFrame(f);
                    EditorFrame.dispose();
                }
            });
            libriArea.append(LibroGiusto);
            AuthorPanel.add(libriArea);
            AuthorPanel.add(OkButton);
            EditorFrame.add(AuthorPanel);
            EditorFrame.setVisible(true);
        }
        else if (LibroGiusto.equals(""))
        {
            JOptionPane.showMessageDialog(EditorFrame,"Nessun libro è di questo editore");
            new MainFrame(f);
        }
    }

    public static void CercaAnno(FileManager f, Frame Mfr) {
        Mfr.dispose();
        String autore = JOptionPane.showInputDialog("Anno di pubblicazione da cercare");
        String LibroGiusto=f.StampaSoloX(autore,3);

        JFrame YearFrame = new JFrame("Filtro per anno di publicazione: ");
        YearFrame.setSize(600,400);
        YearFrame.setLocationRelativeTo(null);
        JTextArea libriArea = new JTextArea();

        ImageIcon Icon= new ImageIcon("../Database/IronShelf.png");
        YearFrame.setIconImage(Icon.getImage());

        JPanel YearPanel = new JPanel();
        YearPanel.setLayout(new BoxLayout(YearPanel, BoxLayout.Y_AXIS));
        JButton OkButton = new JButton("Ok");

        OkButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        OkButton.addActionListener(e -> {
            JOptionPane.showMessageDialog(YearFrame, "Filtro rimosso");
            YearFrame.dispose();
            new MainFrame(f);
        });
        if (!LibroGiusto.equals("")) {
            YearFrame.addWindowListener(new java.awt.event.WindowAdapter() {
                @Override
                public void windowClosing(java.awt.event.WindowEvent e) {
                    new MainFrame(f);
                    YearFrame.dispose();
                }
            });
            libriArea.append(LibroGiusto);
            YearPanel.add(libriArea);
            YearPanel.add(OkButton);
            YearFrame.add(YearPanel);
            YearFrame.setVisible(true);
        }
        else if (LibroGiusto.equals(""))
        {
            JOptionPane.showMessageDialog(YearFrame,"Nessun libro è di quell'anno");
            new MainFrame(f);
        }

    }

    public static void CercaGenere(FileManager f, Frame Mfr) {
        Mfr.dispose();
        String autore = JOptionPane.showInputDialog("Genere da cercare");
        String LibroGiusto=f.StampaSoloX(autore,4);

        JFrame GenereFrame = new JFrame("Filtro per genere: ");
        GenereFrame.setSize(600,400);
        GenereFrame.setLocationRelativeTo(null);
        JTextArea libriArea = new JTextArea();

        ImageIcon Icon= new ImageIcon("../Database/IronShelf.png");
        GenereFrame.setIconImage(Icon.getImage());

        JPanel GenerePanel = new JPanel();
        GenerePanel.setLayout(new BoxLayout(GenerePanel, BoxLayout.Y_AXIS));
        JButton OkButton = new JButton("Ok");

        OkButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        OkButton.addActionListener(e -> {
            JOptionPane.showMessageDialog(GenereFrame, "Filtro rimosso");
            GenereFrame.dispose();
            new MainFrame(f);
        });
        if (!LibroGiusto.equals("")) {
            GenereFrame.addWindowListener(new java.awt.event.WindowAdapter() {
                @Override
                public void windowClosing(java.awt.event.WindowEvent e) {
                    new MainFrame(f);
                    GenereFrame.dispose();
                }
            });
            libriArea.append(LibroGiusto);
            GenerePanel.add(libriArea);
            GenerePanel.add(OkButton);
            GenereFrame.add(GenerePanel);
            GenereFrame.setVisible(true);
        }
        else if (LibroGiusto.equals(""))
        {
            JOptionPane.showMessageDialog(GenereFrame,"Nessun libro è di quel genere");
            new MainFrame(f);
        }

    }

    public static void CercaLibro(FileManager f, Frame Mfr) {
        Mfr.dispose();
        String autore = JOptionPane.showInputDialog("Titolo del libro da cercare");
        // debug System.out.println("Titolo del libro: "+autore);
        String LibroGiusto=f.StampaSoloX(autore,0);

        JFrame TitoloFrame = new JFrame("Filtro per titolo: ");
        TitoloFrame.setSize(600,400);
        TitoloFrame.setLocationRelativeTo(null);
        JTextArea libriArea = new JTextArea();

        ImageIcon Icon= new ImageIcon("../Database/IronShelf.png");
        TitoloFrame.setIconImage(Icon.getImage());

        JPanel TitoloPanel = new JPanel();
        TitoloPanel.setLayout(new BoxLayout(TitoloPanel, BoxLayout.Y_AXIS));
        JButton OkButton = new JButton("Ok");

        OkButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        OkButton.addActionListener(e -> {
            JOptionPane.showMessageDialog(TitoloFrame, "Filtro rimosso");
            TitoloFrame.dispose();
            new MainFrame(f);
        });
        if (!LibroGiusto.equals("")) {
            TitoloFrame.addWindowListener(new java.awt.event.WindowAdapter() {
                @Override
                public void windowClosing(java.awt.event.WindowEvent e) {
                    new MainFrame(f);
                    TitoloFrame.dispose();
                }
            });
            libriArea.append(LibroGiusto);
            TitoloPanel.add(libriArea);
            TitoloPanel.add(OkButton);
            TitoloFrame.add(TitoloPanel);
            TitoloFrame.setVisible(true);
        }
        else if (LibroGiusto.equals(""))
        {
            JOptionPane.showMessageDialog(TitoloFrame,"Nessun libro ha questo titolo");
            new MainFrame(f);
        }

    }

    public static void CercaPeriodo(FileManager f, Frame Mfr) {
        Mfr.dispose();
        JFrame NuovoFrame = new JFrame("Filtro per periodo");
        NuovoFrame.setSize(500, 350);
        NuovoFrame.setLocationRelativeTo(null);
        NuovoFrame.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent e) {
                new MainFrame(f);
                NuovoFrame.dispose();
            }
        });

        ImageIcon Icon= new ImageIcon("../Database/IronShelf.png");
        NuovoFrame.setIconImage(Icon.getImage());

        Gradiente NuovoPanel = new Gradiente(new Color(53, 53, 74), new Color(12, 15, 34));
        NuovoPanel.setLayout(new BoxLayout(NuovoPanel, BoxLayout.Y_AXIS));
        NuovoPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Titolo
        JLabel titolo = new JLabel("Inserisci il periodo di pubblicazione");
        titolo.setForeground(Color.WHITE);
        titolo.setAlignmentX(Component.CENTER_ALIGNMENT);
        titolo.setFont(new Font("Arial", Font.BOLD, 18));

        // Campo Data Min
        JLabel label1 = new JLabel("Data minima (YYYY-MM-DD):");
        label1.setAlignmentX(Component.CENTER_ALIGNMENT);
        label1.setForeground(Color.WHITE);
        JTextField dataMinField = new JTextField();
        dataMinField.setMaximumSize(new Dimension(300, 30));

        // Campo Data Max
        JLabel label2 = new JLabel("Data massima (YYYY-MM-DD):");
        label2.setAlignmentX(Component.CENTER_ALIGNMENT);
        label2.setForeground(Color.WHITE);
        JTextField dataMaxField = new JTextField();
        dataMaxField.setMaximumSize(new Dimension(300, 30));


        // Bottone Cerca
        JButton cercaButton = new JButton("Cerca");
        cercaButton.setForeground(Color.GREEN);
        cercaButton.setOpaque(false);
        cercaButton.setContentAreaFilled(false);
        cercaButton.setBorder(BorderFactory.createLineBorder(Color.GREEN));
        cercaButton.setMaximumSize(new Dimension(150, 35));
        cercaButton.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Bottone Annulla
        JButton indietroButton = new JButton("Annulla");
        indietroButton.setForeground(Color.RED);
        indietroButton.setOpaque(false);
        indietroButton.setContentAreaFilled(false);
        indietroButton.setBorder(BorderFactory.createLineBorder(Color.RED));
        indietroButton.setMaximumSize(new Dimension(150, 35));
        indietroButton.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Azione cerca
        cercaButton.addActionListener(e -> {
            try {
                LocalDate dataMin = LocalDate.parse(dataMinField.getText().trim());
                LocalDate dataMax = LocalDate.parse(dataMaxField.getText().trim());

                if (dataMin.isAfter(dataMax)) {
                    JOptionPane.showMessageDialog(NuovoFrame, "La data minima non può essere dopo la massima!");
                    return;
                }

                String risultati = f.CercaDa_D1toD2(dataMin, dataMax);
                NuovoFrame.dispose();

                // Mostra risultati
                JFrame RisultatiFrame = new JFrame("Libri trovati nel periodo");
                RisultatiFrame.setSize(600, 400);
                RisultatiFrame.setLocationRelativeTo(null);

                JTextArea risultatiArea = new JTextArea();
                risultatiArea.setEditable(false);
                risultatiArea.setText(risultati.isEmpty() ? "Nessun libro trovato nel periodo selezionato." : risultati);

                JPanel risultatiPanel = new JPanel();
                risultatiPanel.setLayout(new BoxLayout(risultatiPanel, BoxLayout.Y_AXIS));

                JButton okButton = new JButton("Ok");
                okButton.setAlignmentX(Component.CENTER_ALIGNMENT);
                okButton.addActionListener(ev -> {
                    RisultatiFrame.dispose();
                    new MainFrame(f);
                });

                risultatiPanel.add(new JScrollPane(risultatiArea));
                risultatiPanel.add(Box.createRigidArea(new Dimension(0, 10)));
                risultatiPanel.add(okButton);

                RisultatiFrame.add(risultatiPanel);
                RisultatiFrame.setVisible(true);

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(NuovoFrame, "Formato data non valido! Usa YYYY-MM-DD.");
            }
        });

        // Azione indietro
        indietroButton.addActionListener(e -> {
            NuovoFrame.dispose();
            new MainFrame(f);
        });

        // Composizione grafica
        NuovoPanel.add(titolo);
        NuovoPanel.add(Box.createRigidArea(new Dimension(0, 30)));
        NuovoPanel.add(label1);
        NuovoPanel.add(dataMinField);
        NuovoPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        NuovoPanel.add(label2);
        NuovoPanel.add(dataMaxField);
        NuovoPanel.add(Box.createRigidArea(new Dimension(0, 30)));
        NuovoPanel.add(cercaButton);
        NuovoPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        NuovoPanel.add(indietroButton);

        NuovoFrame.add(NuovoPanel);
        NuovoFrame.setVisible(true);
    }

    public static void ModificaDialog(FileManager f, Frame Mfr) {

        String VecchioTitolo=JOptionPane.showInputDialog("Inserisci il titolo del libro da modificare");
        String[] infoLibro= f.StampaSoloX(VecchioTitolo,0).split("\n");
        String[] Titolo=infoLibro[0].split("Titolo: ");
        String[] Autore=infoLibro[1].split("Autore: ");
        String[] CasaEditrice=infoLibro[2].split("Casa editrice: ");
        String[] DataDiPubb=infoLibro[3].split("Data di pubblicazione: ");
        year=LocalDate.parse(DataDiPubb[1]);
        String[] Genere=infoLibro[4].split("Genere: ");

        Mfr.dispose();
        JFrame addBookFrame = new JFrame("Edit Book");
        addBookFrame.setSize(500, 400);
        addBookFrame.setLocationRelativeTo(null);

        ImageIcon Icon= new ImageIcon("../Database/IronShelf.png");
        addBookFrame.setIconImage(Icon.getImage());

        JPanel addBookPanel = new JPanel();
        addBookPanel.setLayout(new BoxLayout(addBookPanel, BoxLayout.Y_AXIS));
        addBookPanel.setBackground(Color.BLACK);

        Insets labelInsets = new Insets(5, 10, 5, 10);
        Insets fieldInsets = new Insets(5, 10, 5, 10);

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(Color.BLACK);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.weightx = 1;

        JLabel titleLabel = new JLabel("Titolo:");
        titleLabel.setForeground(Color.white);
        JTextField titleField = new JTextField(Titolo[1]);
        titleField.setPreferredSize(new Dimension(200, 30));

        JLabel authorLabel = new JLabel("Autore:");
        authorLabel.setForeground(Color.white);
        JTextField authorField = new JTextField(Autore[1]);
        authorField.setPreferredSize(new Dimension(200, 30));

        JLabel publisherLabel = new JLabel("Casa Editrice:");
        publisherLabel.setForeground(Color.white);
        JTextField publisherField = new JTextField(CasaEditrice[1]);
        publisherField.setPreferredSize(new Dimension(200, 30));


        JLabel yearLabel = new JLabel("Data di pubblicazione:");
        yearLabel.setForeground(Color.white);
        String stingaAnno= "Data attuale: "+DataDiPubb[1];
        JButton yearField = new JButton(stingaAnno);
        yearField.setPreferredSize(new Dimension(200, 30));

        JLabel genereLabel = new JLabel("Genere:");
        genereLabel.setForeground(Color.white);
        String[] genres = {"Horror", "Romance", "Fantasy", "Si-Fi"};
        JComboBox<String> genereDropdown = new JComboBox<>(genres);
        genereDropdown.setMaximumSize(new Dimension(200, 30));
        int cont=0;
        do {
            if(Genere[1].equals(genres[cont]))
            {
                break;
            }
            cont++;
        }
        while(false);
        genereDropdown.setSelectedIndex(cont);

        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(titleLabel, gbc);
        gbc.gridx = 1;
        formPanel.add(titleField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        formPanel.add(authorLabel, gbc);
        gbc.gridx = 1;
        formPanel.add(authorField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        formPanel.add(publisherLabel, gbc);
        gbc.gridx = 1;
        formPanel.add(publisherField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        formPanel.add(yearLabel, gbc);
        gbc.gridx = 1;
        formPanel.add(yearField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        formPanel.add(genereLabel, gbc);
        gbc.gridx = 1;
        formPanel.add(genereDropdown, gbc);

        yearField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new Calendario(); // Apri il calendario
            }
        });

        JButton saveButton = new JButton("Save");
        saveButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                year = Calendario.selectedDate;
                System.out.println("Data selezionata correttamente: " + year);
                yearField.setText(year.toString());

                String title = titleField.getText();
                String author = authorField.getText();
                String publisher = publisherField.getText();
                String anno = String.valueOf(year);
                String genere = (String) genereDropdown.getSelectedItem();
                try {
                    System.out.println(year);
                    if (year.isAfter(LocalDate.now()))
                    {
                        JOptionPane.showMessageDialog(addBookFrame, "Inserisci un anno valido");
                    }
                    else if(title.equals("Inserisci titolo...") || author.equals("Inserisci autore...") || publisher.equals("Inserisci casa editrice...") || anno.equals("Inserisci data(yyyy-MM-dd)..."))
                    {
                        JOptionPane.showMessageDialog(addBookFrame, "Ci sono dei campi vuoti!");
                    }
                    else
                    {
                        f.modifica(title,author,publisher,year,genere,VecchioTitolo);
                        JOptionPane.showMessageDialog(addBookFrame, "Libro aggiunto con successo!!");
                        new MainFrame(f);
                        addBookFrame.dispose();
                    }
                } catch (DateTimeParseException datEx) {
                    datEx.printStackTrace();
                    JOptionPane.showMessageDialog(addBookFrame, "Inserisci un anno valido");
                    yearField.setText("");
                }
            }
        });

        addBookFrame.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent e) {
                new MainFrame(f);
                addBookFrame.dispose();
            }
        });
        saveButton.setAlignmentX(Component.CENTER_ALIGNMENT);

        addBookPanel.add(formPanel);
        addBookPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        addBookPanel.add(saveButton);

        addBookFrame.add(addBookPanel);
        addBookFrame.setVisible(true);
    }

}