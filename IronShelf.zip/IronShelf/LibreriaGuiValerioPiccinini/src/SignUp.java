import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class SignUp {

    public SignUp(FileLogInManager FileLog) {
        JFrame singUpFrame=new JFrame("SignUp");
        singUpFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        singUpFrame.setSize(300,200);
        singUpFrame.setLocationRelativeTo(null);

        ImageIcon Icon= new ImageIcon("./Database/IronShelf.png");
        singUpFrame.setIconImage(Icon.getImage());

        Gradiente singUpPanel=new Gradiente(new Color(250, 201, 26), new Color(250, 27, 198));
        singUpPanel.setLayout(new BoxLayout(singUpPanel,BoxLayout.Y_AXIS));

        JPanel occhiolinoPanel=new JPanel();
        occhiolinoPanel.setLayout(new BoxLayout(occhiolinoPanel,BoxLayout.X_AXIS));

        JLabel UserNameLabel=new JLabel("Inserire nuovo nome utente");
        JTextField userNameField=new JTextField("Inserire nuovo utente...");
        userNameField.setMaximumSize(new Dimension(200,20));
        userNameField.setForeground(Color.GRAY);
        userNameField.addFocusListener(new FocusListener(){
            public void focusGained(FocusEvent e) {
                if(userNameField.getText().equals("Inserire nuovo utente..."))
                {
                    userNameField.setText("");
                    userNameField.setForeground(Color.black);
                }
            }
            public void focusLost(FocusEvent e) {
                if (userNameField.getText().isEmpty()) {
                    userNameField.setText("Inserire nuovo utente...");
                    userNameField.setForeground(Color.GRAY);
                }
            }
        });
        userNameField.setAlignmentX(Component.CENTER_ALIGNMENT);
        UserNameLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel PasswordLabel=new JLabel("Inserire nuova password");
        JTextField passwordField=new JTextField("Inserire nuova password...");
        passwordField.setMaximumSize(new Dimension(200,20));
        passwordField.setForeground(Color.GRAY);
        passwordField.addFocusListener(new FocusListener(){
            public void focusGained(FocusEvent e) {
                if(passwordField.getText().equals("Inserire nuova password..."))
                {
                    passwordField.setText("");
                    passwordField.setForeground(Color.black);
                }
            }
            public void focusLost(FocusEvent e) {
                if (passwordField.getText().isEmpty()) {
                    passwordField.setText("Inserire nuova password...");
                    passwordField.setForeground(Color.GRAY);
                }
            }
        });
        passwordField.setAlignmentX(Component.CENTER_ALIGNMENT);
        PasswordLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel AddPasswordLabel=new JLabel("Inserire la password di autenticazione");
        JPasswordField AddpasswordField=new JPasswordField();
        AddpasswordField.setMaximumSize(new Dimension(200,20));
        AddpasswordField.setAlignmentX(Component.CENTER_ALIGNMENT);
        AddPasswordLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        JToggleButton toggleButton = new JToggleButton("👁️"); // Aggiungi un listener per il toggle button
        toggleButton.addItemListener(new ItemListener() {
            @Override public void itemStateChanged(ItemEvent e)
            { if (e.getStateChange() == ItemEvent.SELECTED)
            { // Mostra la password in chiaro
                AddpasswordField.setEchoChar((char) 0); // Caratteri visibili
            }
            else // Nasconde la password con un asterisco
            {
                AddpasswordField.setEchoChar('•'); // Caratteri mascherati
            } } });
        occhiolinoPanel.add(AddpasswordField);
        occhiolinoPanel.add(toggleButton);

        JButton SingUpButton=new JButton("Sing Up");
        SingUpButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        SingUpButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String User=userNameField.getText();
                String Passwd=passwordField.getText();
                String AddPassword=AddpasswordField.getText();
                if(FileLog.NewUser(User,Passwd, AddPassword, singUpFrame))
                {
                    JOptionPane.showMessageDialog(singUpFrame, "SingUp Successful");
                    singUpFrame.dispose();
                    String FileName = "../Database/DatabaseLibreria.txt";
                    FileManager file = new FileManager(FileName);
                    new MainFrame(file);
                }
                else
                {
                    JOptionPane.showMessageDialog(singUpFrame, "Nome Utente o password già in uso");
                    userNameField.setText("");
                    passwordField.setText("");
                    AddpasswordField.setText("");
                }
            }
        });

        singUpPanel.add(UserNameLabel);
        singUpPanel.add(userNameField);
        singUpPanel.add(PasswordLabel);
        singUpPanel.add(passwordField);
        singUpPanel.add(AddPasswordLabel);
        singUpPanel.add(occhiolinoPanel);
        singUpPanel.add(SingUpButton);
        singUpFrame.add(singUpPanel);


        singUpFrame.setVisible(true);
    }

}