import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.io.BufferedWriter;
import java.time.LocalDate;

public class FileManager {
    File file;

    public FileManager(String fileName) {
        file = new File(fileName);
        try {
            file.createNewFile();
        } catch (IOException e) {
            System.out.println("Error creating file");
        }
    }

    public String readFile() {
        String books = "";
        try (Scanner scanner = new Scanner(new File(file.getAbsolutePath()))) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine() + "\n";
                books += line;
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return books;
    }

    public void EliminaDaTitolo(String titolo) {
        titolo = "Titolo: " + titolo;

        StringBuilder LibriDaSalvare = new StringBuilder();
        boolean trovato = false;

        try (Scanner scanner = new Scanner(new File(file.getAbsolutePath()))) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine().trim(); // Eliminiamo spazi extra

                // Se la riga corrisponde al titolo, saltiamo le successive 5 righe
                if (line.equals(titolo)) { // Controllo case-insensitive

                    trovato = true;
                    int cont = 5;
                    while (cont > 0 && scanner.hasNextLine()) {
                        scanner.nextLine();
                        cont--;
                    }
                } else {
                    // Aggiungiamo la riga al buffer
                    LibriDaSalvare.append(line).append("\n");
                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return;
        }

        // Se il libro non è stato trovato, avvisiamo
        if (!trovato) {
            return;
        }

        // Sovrascriviamo il file con i libri rimasti
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
            writer.write(LibriDaSalvare.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void InserisciLibro(String title, String author, String publisher, LocalDate year, String genere) {
        try (FileWriter writer = new FileWriter(file.getAbsolutePath(), true)) {
            writer.append("Titolo: " + title + "\n");
            writer.append("Autore: " + author + "\n");
            writer.append("Casa editrice: " + publisher + "\n");
            writer.append("Data di pubblicazione: " + year + "\n");
            writer.append("Genere: " + genere + "\n");
            writer.append("****************************************\n");
        } catch (IOException io) {
            io.printStackTrace();
        }
    }

    public String StampaSoloX(String author, int posx) {
        if (posx == 0) {
            author = "Titolo: " + author;
        } else if (posx == 1) {
            author = "Autore: " + author;
        } else if (posx == 2) {
            author = "Casa editrice: " + author;

        } else if (posx == 3) {
            author = "Data di pubblicazione: " + author;
        } else if (posx == 4) {
            author = "Genere: " + author;
        }
        try (Scanner scanner = new Scanner(new File(file.getAbsolutePath()))) {
            String Libro = "";
            String LibroGiusto = "";
            String line;
            Boolean AutoreTrovato = false;
            while (scanner.hasNextLine()) {
                for (int i = 0; i < 6; i++) {
                    line = scanner.nextLine();
                    Libro = Libro + line + "\n";
                    if (i == posx) {
                        if (line.contains(author)) {
                            AutoreTrovato = true;
                        }
                    }
                }
                if (AutoreTrovato) {
                    LibroGiusto = LibroGiusto + Libro;
                }
                AutoreTrovato = false;
                Libro = "";
            }
            return LibroGiusto;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return null;
        }
    }

    public String CercaDa_D1toD2(LocalDate D1, LocalDate D2) {
        StringBuilder libroGiusto = new StringBuilder();
        try (Scanner scanner = new Scanner(new File(file.getAbsolutePath()))) {
            while (scanner.hasNextLine()) {
                StringBuilder books = new StringBuilder();
                String dataPubblicazione = null;

                // Leggo le 6 righe del libro (se ci sono)
                for (int i = 0; i < 6; i++) {
                    if (!scanner.hasNextLine()) break;
                    String line = scanner.nextLine();
                    books.append(line).append("\n");

                    // Controllo robusto sulla data
                    if (i == 3 && line.toLowerCase().startsWith("data di pubblicazione: ")) {
                        dataPubblicazione = line.substring(line.indexOf(":") + 1).trim();
                    }
                }

                if (dataPubblicazione != null) {
                    try {
                        LocalDate data = LocalDate.parse(dataPubblicazione);
                        if ((data.isEqual(D1) || data.isAfter(D1)) && (data.isEqual(D2) || data.isBefore(D2))) {
                            libroGiusto.append(books);
                        }
                    } catch (Exception e) {
                        System.out.println("Formato data non valido: " + dataPubblicazione);
                    }
                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return libroGiusto.toString();
    }

    public void modifica(String title, String author, String publisher, LocalDate year, String genere, String OldTitle) {
        StringBuilder LibriPrima = new StringBuilder();
        StringBuilder LibriDopo = new StringBuilder();
        boolean trovato = false;
        String line = "";

        try (Scanner scanner = new Scanner(new File(file.getAbsolutePath()))) {
            while (scanner.hasNextLine()) {
                line = scanner.nextLine() + "\n";

                if (!trovato && line.startsWith("Titolo: ") && line.contains(OldTitle)) {
                    trovato = true; // Abbiamo trovato il libro da modificare
                    // Saltare le 5 righe successive del vecchio libro
                    for (int i = 0; i < 5; i++) {
                        if (scanner.hasNextLine()) scanner.nextLine();
                    }
                }
                else {
                    if (!trovato) {
                        LibriPrima.append(line); // Scriviamo tutto ciò che viene prima del libro
                    } else {
                        LibriDopo.append(line); // Scriviamo tutto ciò che viene dopo
                    }
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("Errore durante la lettura nel file.");
            return;
        }

        // Creiamo la nuova versione aggiornata del libro
        String LibroAggiornato = "Titolo: " + title + "\n" +
                "Autore: " + author + "\n" +
                "Casa editrice: " + publisher + "\n" +
                "Data di pubblicazione: " + year + "\n" +
                "Genere: " + genere + "\n" +
                "****************************************\n";

        // Scriviamo tutto il contenuto corretto nel file
        try (FileWriter FW = new FileWriter(file.getAbsolutePath(),false)) {
            FW.write(LibriPrima.toString());
            FW.write(LibroAggiornato);
            FW.write(LibriDopo.toString());
        } catch (IOException e) {
            System.out.println("Errore durante la scrittura nel file.");
        }
    }
}