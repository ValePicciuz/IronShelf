import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class LogIn {

    public LogIn(FileLogInManager FileLog) {
        //impostazione del frame
        JFrame logInFrame = new JFrame("LogIn");
        logInFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        logInFrame.setSize(300,200);
        logInFrame.setLocationRelativeTo(null);

        ImageIcon Icon= new ImageIcon("./Database/IronShelf.png");
        logInFrame.setIconImage(Icon.getImage());

        //impostazione del panel
        Gradiente logInPanel = new Gradiente(new Color(250, 27, 198), new Color(83, 244, 246));
        logInPanel.setLayout(new BoxLayout(logInPanel,BoxLayout.Y_AXIS));

        JPanel occhioPanel = new JPanel();
        occhioPanel.setLayout(new BoxLayout(occhioPanel,BoxLayout.X_AXIS));

        JLabel UserNAmeInLabel = new JLabel("Nome Utente");
        //UserNAmeInLabel.setForeground();
        JTextField UserNameField = new JTextField("Inserisci utente...");
        UserNameField.setMaximumSize(new Dimension(200, 20));
        UserNameField.setAlignmentX(Component.CENTER_ALIGNMENT);
        UserNAmeInLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        UserNameField.setForeground(Color.GRAY);
        UserNameField.addFocusListener(new FocusListener() {
            public void focusGained(FocusEvent e) {
                if(UserNameField.getText().equals("Inserisci utente..."))
                {
                    UserNameField.setText("");
                    UserNameField.setForeground(Color.black);
                }
            }
            public void focusLost(FocusEvent e) {
                if (UserNameField.getText().isEmpty()) {
                    UserNameField.setText("Inserisci utente...");
                    UserNameField.setForeground(Color.GRAY);
                }
            }
        });

        JLabel PasswordInLabel = new JLabel("Password");
        JPasswordField PasswordField = new JPasswordField();
        PasswordField.setMaximumSize(new Dimension(200, 20));
        PasswordField.setAlignmentX(Component.CENTER_ALIGNMENT);
        PasswordInLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        PasswordField.setForeground(Color.black);

        JButton logInButton = new JButton("Submit");
        logInButton.setAlignmentX(Component.CENTER_ALIGNMENT);

        logInButton.addActionListener(new ActionListener() {
            int cont=0;
            public void actionPerformed(ActionEvent e) {
                String userName = UserNameField.getText();
                String password = PasswordField.getText();
                if(FileLog.LogInRead(userName, password) && cont<3)
                {
                    JOptionPane.showMessageDialog(logInFrame, "Benvunuto/a "+userName+"!");
                    logInFrame.dispose();
                    String FileName = "./Database/DatabaseLibreria.txt";
                    FileManager file = new FileManager(FileName);
                   new MainFrame(file);
                }
                else if(cont>=2)
                {
                    JOptionPane.showMessageDialog(logInFrame, "Tentativi esauriti, mi dispiace");
                    System.exit(1);
                }
                else if(PasswordField.getText().equals("Inserisci password...") || UserNameField.getText().equals("Inserisci utente..."))
                {
                    JOptionPane.showMessageDialog(logInFrame, "Tutti i campi sono obbligatori!");
                }
                else
                {
                    cont++;
                    JOptionPane.showMessageDialog(logInFrame, "Nome utente o password errati");
                    UserNameField.setText("");
                    PasswordField.setText("");
                }
            }
        });
        JToggleButton toggleButton = new JToggleButton("👁️"); // Aggiungi un listener per il toggle button
        toggleButton.addItemListener(new ItemListener() {
            @Override public void itemStateChanged(ItemEvent e)
            { if (e.getStateChange() == ItemEvent.SELECTED)
            { // Mostra la password in chiaro
                PasswordField.setEchoChar((char) 0); // Caratteri visibili
            }
            else // Nasconde la password con un asterisco
            {
                PasswordField.setEchoChar('•'); // Caratteri mascherati
            } } });
        occhioPanel.add(PasswordField);
        occhioPanel.add(toggleButton);

        //aggiungo tutto al panel
        logInPanel.add(UserNAmeInLabel);
        logInPanel.add(UserNameField);
        logInPanel.add(PasswordInLabel);
        logInPanel.add(occhioPanel);
        logInPanel.add(Box.createRigidArea(new Dimension(0,20)));
        logInPanel.add(logInButton);

        //aggiunta del panel sul frame
        logInFrame.add(logInPanel);
        logInFrame.setVisible(true);
    }

}