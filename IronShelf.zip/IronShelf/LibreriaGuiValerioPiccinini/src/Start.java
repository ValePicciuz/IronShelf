import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Start {

    public Start(FileLogInManager log) {
        JFrame StartFrame = new JFrame();
        StartFrame.setSize(300, 300);
        StartFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //StartFrame.setBackground(Color.black);
        StartFrame.setLocationRelativeTo(null);
        ImageIcon Icon= new ImageIcon("../Database/IronShelf.png");
        StartFrame.setIconImage(Icon.getImage());
        Gradiente StartPanel = new Gradiente(new Color(83, 244, 246), new Color(250, 201, 26));
        StartPanel.setLayout(new BoxLayout(StartPanel, BoxLayout.Y_AXIS));
        JLabel WelcomeLabel=new JLabel("Benvenuto cosa vuole fare?");
        WelcomeLabel.setForeground(Color.white);
        WelcomeLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        JLabel ACapoLabel=new JLabel("\n");
        JLabel ACapoLabel2=new JLabel("\n");
        JLabel ACapoLabel3=new JLabel("\n");

        JPanel ButtonPanel = new JPanel();
        ButtonPanel.setLayout(new BoxLayout(ButtonPanel, BoxLayout.X_AXIS));
        JButton LogInButton = new JButton("Log In");
        LogInButton.setMaximumSize(new Dimension(100, 30));
        LogInButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        LogInButton.setAlignmentY(Component.CENTER_ALIGNMENT);
        LogInButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new LogIn(log);
                StartFrame.dispose();
            }
        });

        JButton SingUpButton = new JButton("Sign Up");
        SingUpButton.setMaximumSize(new Dimension(100,30));
        SingUpButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        SingUpButton.setAlignmentY(Component.CENTER_ALIGNMENT);
        SingUpButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new SignUp(log);
                StartFrame.dispose();
            }
        });

        //Immagine I= new Immagine("./Progetto Libreria/Database/IronShelf.png");
        Immagine I= new Immagine("../Database/IronShelf.png");
        I.setMaximumSize(new Dimension(130, 130));

        StartPanel.add(WelcomeLabel);
        StartPanel.add(ACapoLabel);
        ButtonPanel.add(LogInButton);
        ButtonPanel.add(SingUpButton);
        StartPanel.add(ButtonPanel);
        StartPanel.add(ACapoLabel2);
        StartPanel.add(ACapoLabel3);
        StartPanel.add(I);
        StartFrame.add(StartPanel);
        StartFrame.setVisible(true);
    }
    
}