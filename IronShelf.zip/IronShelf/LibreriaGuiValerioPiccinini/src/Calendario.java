import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Calendar;
import java.time.LocalDate;

public class Calendario {
    public static LocalDate selectedDate;

    public Calendario() {
        JFrame frame = new JFrame("Calendario");
        frame.setSize(400, 450);
        frame.setLayout(new BorderLayout());
        ImageIcon Icon= new ImageIcon("../Database/IronShelf.png");
        frame.setIconImage(Icon.getImage());

        // 🔹 Pannello superiore per selezionare mese e anno
        JPanel controlPanel = new JPanel();
        controlPanel.setBackground(new Color(85, 239, 9));
        controlPanel.setLayout(new FlowLayout());

        String[] months = {"Gen", "Feb", "Mar", "Apr", "Mag", "Giu", "Lug", "Ago", "Set", "Ott", "Nov", "Dic"};
        JComboBox<String> monthComboBox = new JComboBox<>(months);
        monthComboBox.setSelectedIndex(Calendar.getInstance().get(Calendar.MONTH));

        JTextField yearTextField = new JTextField(5);
        int currentYear = Calendar.getInstance().get(Calendar.YEAR);
        yearTextField.setText(String.valueOf(currentYear));

        controlPanel.add(new JLabel("Mese:"));
        controlPanel.add(monthComboBox);
        controlPanel.add(new JLabel("Anno:"));
        controlPanel.add(yearTextField);

        // 🔹 Pannello principale con immagine di sfondo
        JPanel imagePanel = new JPanel() {
            private Image backgroundImage = new ImageIcon("../Database/Immagine.png").getImage();

            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
            }
        };
        imagePanel.setLayout(new BorderLayout());

        // 🔹 Pannello per il calendario (trasparente)
        JPanel calendarPanel = new JPanel(new GridLayout(0, 7));
        calendarPanel.setOpaque(false);

        // 🔹 Aggiunta dei nomi dei giorni
        String[] daysOfWeek = {"Dom", "Lun", "Mar", "Mer", "Gio", "Ven", "Sab"};
        for (String day : daysOfWeek) {
            JLabel label = new JLabel(day, SwingConstants.CENTER);
            label.setForeground(Color.WHITE);
            calendarPanel.add(label);
        }

        // 🔹 Aggiunta bottoni trasparenti
        ActionListener updateCalendar = e -> {
            int selectedMonth = monthComboBox.getSelectedIndex();
            int selectedYear;

            try {
                selectedYear = Integer.parseInt(yearTextField.getText());
                if (selectedYear < 1000 || selectedYear > LocalDate.now().getYear()) {
                    throw new NumberFormatException();
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(frame, "Inserisci un anno valido tra 1000 e l'anno attuale!", "Errore", JOptionPane.ERROR_MESSAGE);
                return;
            }

            Calendar currentDate = Calendar.getInstance();
            currentDate.set(selectedYear, selectedMonth, 1);

            int firstDayOfMonth = currentDate.get(Calendar.DAY_OF_WEEK);
            int daysInMonth = currentDate.getActualMaximum(Calendar.DAY_OF_MONTH);

            calendarPanel.removeAll();
            for (String day : daysOfWeek) {
                JLabel label = new JLabel(day, SwingConstants.CENTER);
                label.setForeground(Color.WHITE);
                calendarPanel.add(label);
            }

            // Celle vuote prima del primo giorno del mese
            int emptyCells = firstDayOfMonth - 1;
            for (int i = 0; i < emptyCells; i++) {
                calendarPanel.add(new JLabel(""));
            }

            // Aggiunta bottoni trasparenti per i giorni del mese
            for (int day = 1; day <= daysInMonth; day++) {
                JButton dayButton = new JButton(String.valueOf(day));
                //dayButton.setBorder(BorderFactory.createLineBorder(new Color(8, 40, 202)));
                dayButton.setForeground(new Color(85, 239, 9));
                dayButton.setOpaque(false);
                dayButton.setContentAreaFilled(false);
                dayButton.addActionListener(ev -> {
                    if(Integer.parseInt(dayButton.getText())<10) {
                        selectedDate = LocalDate.parse(selectedYear + "-" + String.format("%02d", selectedMonth+1) + "-0" + (dayButton.getText()));
                    }
                    else {
                    selectedDate = LocalDate.parse(selectedYear + "-" + String.format("%02d", selectedMonth+1) + "-" + (dayButton.getText()));
                    }
                    JOptionPane.showMessageDialog(frame, "Hai selezionato la data: " + selectedDate);
                });
                calendarPanel.add(dayButton);
            }

            calendarPanel.revalidate();
            calendarPanel.repaint();
        };

        monthComboBox.addActionListener(updateCalendar);
        yearTextField.addActionListener(e -> updateCalendar.actionPerformed(null));

        // 🔹 Pannello inferiore con bottone di salvataggio
        JPanel bottomPanel = new JPanel();
        bottomPanel.setBackground(new Color(150, 106, 186));

        JButton saveButton = new JButton("Salva");
        saveButton.addActionListener(e -> {
            if (selectedDate != null) {
                frame.dispose();
            }
            else {
                JOptionPane.showMessageDialog(frame, "Nessuna data selezionata!");
            }
        });

        bottomPanel.add(saveButton);

        // 🔹 Aggiunta dei pannelli alla finestra
        imagePanel.add(calendarPanel, BorderLayout.CENTER);
        frame.add(controlPanel, BorderLayout.NORTH);
        frame.add(imagePanel, BorderLayout.CENTER);
        frame.add(bottomPanel, BorderLayout.SOUTH);

        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setVisible(true);

        updateCalendar.actionPerformed(null);
    }

}