import javax.swing.*;
import java.awt.*;

public class Immagine extends JPanel {
    private Image backgroundImage;

    // Costruttore che carica l'immagine
    public Immagine(String filePath) {
        backgroundImage = new ImageIcon(filePath).getImage();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
    }
}